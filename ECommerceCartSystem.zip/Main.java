import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Product> catalog = Arrays.asList(
            new Product(1, "T-Shirt", 19.99),
            new Product(2, "Jeans", 49.99),
            new Product(3, "Sneakers", 89.99)
        );

        Cart cart = new Cart();
        int choice;

        do {
            System.out.println("\n1. View Products\n2. Add to Cart\n3. View Cart\n4. Remove from Cart\n5. Checkout\n6. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    for (Product p : catalog) {
                        System.out.println(p);
                    }
                    break;
                case 2:
                    System.out.print("Enter product ID: ");
                    int id = scanner.nextInt();
                    System.out.print("Enter quantity: ");
                    int qty = scanner.nextInt();
                    Product product = catalog.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
                    if (product != null) {
                        cart.addItem(product, qty);
                        System.out.println("Added to cart.");
                    } else {
                        System.out.println("Invalid product ID.");
                    }
                    break;
                case 3:
                    cart.viewCart();
                    break;
                case 4:
                    System.out.print("Enter product ID to remove: ");
                    int removeId = scanner.nextInt();
                    cart.removeItem(removeId);
                    System.out.println("Removed from cart.");
                    break;
                case 5:
                    cart.checkout();
                    break;
                case 6:
                    System.out.println("Thank you for shopping!");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        } while (choice != 6);
    }
}