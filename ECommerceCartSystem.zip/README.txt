ECommerce Cart System - Java Console Application

How to Run:
1. Compile all Java files:
   javac *.java

2. Run the application:
   java Main

Features:
- View product catalog
- Add items to cart
- Remove items
- View cart
- Checkout and total bill